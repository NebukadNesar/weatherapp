import React, { Component } from "react";
import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      placeName: "",
      selectedDate: "",
      dates: [],
      places: [],
      result:""
    };

    this.getDates = this.getDates.bind(this);
    this.getPlaces = this.getPlaces.bind(this);
    this.getPlacesList = this.getPlacesList.bind(this);
    this.getForecast = this.getForecast.bind(this);
    this.getDateOptions = this.getDateOptions.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.onPlaceNameChange = this.onPlaceNameChange.bind(this);
    this.autoSetPlace = this.autoSetPlace.bind(this);
  }
  
  componentDidMount() {
    this.getDates();
    this.getPlaces();
  }

  getDates = async () => {
    const response = await fetch(
      "http://localhost:5544/weather/getforecastdates",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      }
    );
    const dates = await response.json(); //extract JSON from the http response
    this.setState({ dates });
    this.setState({selectedDate: dates[0]});
  };

  getPlaces = async () => {
    const response = await fetch(
      "http://localhost:5544/weather/getavailablecitynames",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      }
    );
    const places = await response.json(); //extract JSON from the http response
    this.setState({ places });
  };

  getPlacesList() {
    const list = [];
    this.state.places.forEach(place => {
      list.push(
        <li className="citystate" key={place} value={place} onClick={()=>this.autoSetPlace(place)}>
          {place}
        </li>
      );
    });
    return list;
  }

  autoSetPlace(name){
    this.setState({placeName:name});  
  }

  getForecast = async () => {
    const url = new URL("http://localhost:5544/weather/getcity");
    const theDate = this.state.selectedDate ? this.state.selectedDate : "";
    const thePlace = this.state.placeName ? this.state.placeName : "";

    var params = { date: theDate, cityName: thePlace };
    console.log(params)
    Object.keys(params).forEach(key =>
      url.searchParams.append(key, params[key])
    );

    console.log(url)
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    }); 
    const respnse = await response.json(); //extract JSON from the http response 
    this.setState({result:JSON.stringify(respnse)});
  };

  getDateOptions() {
    const list = [];
    this.state.dates.forEach((date, index) => {
      if (index === 0) {
        list.push(
          <option key={date} value={date} selected="selected">
            {date}
          </option>
        );
      } else {
        list.push(
          <option key={date} value={date}>
            {date}
          </option>
        );
      }
    });
    return list;
  }

  handleChange(event) {
    this.setState({ selectedDate: event.target.value });
  }
  onPlaceNameChange(event) {
    this.setState({ placeName: event.target.value });
  }

  render() {
    return (
      <div className="App">
        <header>Weather App</header>
        <div className="selectboxid">
          <select id="dateselectbox" onChange={this.handleChange}>
            <option value="select">Select a Date</option>
            {this.getDateOptions()}
          </select>
        </div>
        <div id="placesid" className="placeslist">
          <ul>{this.getPlacesList()}</ul>
        </div>
        <div className="requestTab">
          <input
            text="place name"
            id="placenameid"
            onChange={this.onPlaceNameChange}
            refs="placeNameNode"
            value={this.state.placeName}
          />
          <button id="getforecastbuttonid" onClick={this.getForecast}>
            Get Forecast
          </button>
        </div>
        <div className="forecastresult">
          {this.state.result}
        </div>

      </div>
    );
  }
}

export default App;
